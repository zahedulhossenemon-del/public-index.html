# Chips kinun backend
1. Install Node 18+. In this folder: `npm install`
2. Edit GAMES (rates) and REFS in server.js so they match the website.
3. Run: `ADMIN_KEY=your-long-secret node server.js` (Windows: `set ADMIN_KEY=...` first)
4. Admin dashboard: http://localhost:3000/admin (enter your key)
5. Deploy (Render / Railway / VPS), then set `API_URL` in the website's CFG to your server URL, and set ALLOWED_ORIGIN to your site's domain.
Orders are saved in orders.json (back it up). For high volume, move to a real database.

## Telegram order alerts
1. In Telegram, message @BotFather, send /newbot, and copy the bot token.
2. Open your new bot and press Start (for a group: add the bot to the group).
3. Get your chat ID: message @userinfobot (or for a group, open https://api.telegram.org/bot<TOKEN>/getUpdates after sending a message and read chat.id).
4. Run with: `TELEGRAM_BOT_TOKEN=... TELEGRAM_CHAT_ID=... ADMIN_KEY=... node server.js`
Every new order will then arrive as a Telegram message. Needs Node 18+.

## Database (PostgreSQL)
1. Create a free Postgres database (Neon.tech or Supabase, or Render's PostgreSQL) and copy its connection string.
2. Set it as the `DATABASE_URL` environment variable on your server. The orders table is created automatically on first start.
3. Run `npm install` again (adds the `pg` package).
Without DATABASE_URL the server falls back to orders.json (testing only).
