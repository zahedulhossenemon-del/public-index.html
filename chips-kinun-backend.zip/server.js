// Chips kinun backend. Setup: npm install && ADMIN_KEY=your-secret node server.js
// Database: set DATABASE_URL for PostgreSQL (recommended for hosting). Without it, orders go to a local orders.json file (testing only).
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
app.set("trust proxy", 1);
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" })); // set ALLOWED_ORIGIN=https://yourdomain.com in production
app.use(express.json({ limit: "20kb" }));

// ===== CONFIG: must match the rates in the website's CFG =====
const GAMES = {            // taka per 1 crore (1 Cr) chips, minimum chips in crore
  "Teen Patti Gold": { rate: 75, min: 1 },
  "Ace Pro":         { rate: 45, min: 1 },
  "Royal":           { rate: 52, min: 1 },
};
const REFS = { DEMO10: { discountPct: 10 } };   // agent reference codes
const STATUSES = ["Pending", "Paid", "Delivered", "Rejected"];
// ==============================================================

const ADMIN_KEY = process.env.ADMIN_KEY;
if (!ADMIN_KEY || ADMIN_KEY === "change-me") { console.error("Set a strong ADMIN_KEY env variable."); process.exit(1); }

// ---------- Storage ----------
let store;
if (process.env.DATABASE_URL) {
  const { Pool } = require("pg");
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.PGSSL === "disable" ? false : { rejectUnauthorized: false },
  });
  const row = (r) => r && ({
    id: r.id, game: r.game, coins: r.coins, price: r.price, uid: r.uid, contact: r.contact,
    method: r.method, tx: r.tx, status: r.status,
    createdAt: r.created_at.toISOString(), updatedAt: r.updated_at ? r.updated_at.toISOString() : undefined,
  });
  store = {
    async init() {
      await pool.query(`CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY, game TEXT NOT NULL, coins TEXT NOT NULL, price INTEGER NOT NULL,
        uid TEXT NOT NULL, contact TEXT NOT NULL, method TEXT NOT NULL, tx TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending',
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ)`);
      await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS orders_tx_unique ON orders (lower(tx))");
      await pool.query(`CREATE TABLE IF NOT EXISTS banners (
        id SERIAL PRIMARY KEY, img TEXT NOT NULL, game TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
      await pool.query(`CREATE TABLE IF NOT EXISTS offers (
        id SERIAL PRIMARY KEY, title TEXT NOT NULL, text TEXT NOT NULL DEFAULT '', game TEXT NOT NULL DEFAULT '',
        discount_pct INTEGER NOT NULL DEFAULT 0, created_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
      await pool.query("ALTER TABLE offers ADD COLUMN IF NOT EXISTS image TEXT NOT NULL DEFAULT ''");
    },
    async insert(o) {
      try {
        const r = await pool.query(
          `INSERT INTO orders (id,game,coins,price,uid,contact,method,tx,status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'Pending') RETURNING *`,
          [o.id, o.game, o.coins, o.price, o.uid, o.contact, o.method, o.tx]);
        return row(r.rows[0]);
      } catch (e) { if (e.code === "23505") { const d = new Error("dup"); d.dup = true; throw d; } throw e; }
    },
    async get(id) { return row((await pool.query("SELECT * FROM orders WHERE id=$1", [id])).rows[0]); },
    async list() { return (await pool.query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 1000")).rows.map(row); },
    async setStatus(id, s) { return row((await pool.query("UPDATE orders SET status=$2, updated_at=now() WHERE id=$1 RETURNING *", [id, s])).rows[0]); },
    async offers() {
      return (await pool.query("SELECT * FROM offers ORDER BY id DESC")).rows
        .map((r) => ({ id: r.id, title: r.title, text: r.text, game: r.game, discountPct: r.discount_pct, image: r.image }));
    },
    async addOffer(o) {
      const r = (await pool.query("INSERT INTO offers (title,text,game,discount_pct,image) VALUES ($1,$2,$3,$4,$5) RETURNING *", [o.title, o.text, o.game, o.discountPct, o.image])).rows[0];
      return { id: r.id, title: r.title, text: r.text, game: r.game, discountPct: r.discount_pct, image: r.image };
    },
    async delOffer(id) { return (await pool.query("DELETE FROM offers WHERE id=$1", [id])).rowCount > 0; },
    async banners() { return (await pool.query("SELECT id,img,game FROM banners ORDER BY id")).rows; },
    async addBanner(b) { return (await pool.query("INSERT INTO banners (img,game) VALUES ($1,$2) RETURNING id,img,game", [b.img, b.game])).rows[0]; },
    async delBanner(id) { return (await pool.query("DELETE FROM banners WHERE id=$1", [id])).rowCount > 0; },
  };
} else {
  const DB = path.join(__dirname, "orders.json");
  const load = () => { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return []; } };
  const save = (d) => { fs.writeFileSync(DB + ".tmp", JSON.stringify(d, null, 2)); fs.renameSync(DB + ".tmp", DB); };
  const OF = path.join(__dirname, "offers.json");
  const loadO = () => { try { return JSON.parse(fs.readFileSync(OF, "utf8")); } catch { return []; } };
  const saveO = (d) => fs.writeFileSync(OF, JSON.stringify(d, null, 2));
  const BF = path.join(__dirname, "banners.json");
  const loadB = () => { try { return JSON.parse(fs.readFileSync(BF, "utf8")); } catch { return []; } };
  const saveB = (d) => fs.writeFileSync(BF, JSON.stringify(d, null, 2));
  console.warn("DATABASE_URL not set: using orders.json (testing only; not safe on most hosts).");
  store = {
    async init() {},
    async insert(o) {
      const all = load();
      if (all.some((x) => x.tx.toLowerCase() === o.tx.toLowerCase())) { const d = new Error("dup"); d.dup = true; throw d; }
      const order = { ...o, status: "Pending", createdAt: new Date().toISOString() };
      all.unshift(order); save(all); return order;
    },
    async get(id) { return load().find((x) => x.id === id) || null; },
    async list() { return load(); },
    async setStatus(id, s) {
      const all = load(), o = all.find((x) => x.id === id);
      if (!o) return null;
      o.status = s; o.updatedAt = new Date().toISOString(); save(all); return o;
    },
    async offers() { return loadO(); },
    async addOffer(o) { const all = loadO(); const n = { id: Date.now(), ...o }; all.unshift(n); saveO(all); return n; },
    async delOffer(id) { const all = loadO(), k = all.filter((x) => String(x.id) !== String(id)); saveO(k); return k.length !== all.length; },
    async banners() { return loadB(); },
    async addBanner(b) { const all = loadB(); const n = { id: Date.now(), ...b }; all.push(n); saveB(all); return n; },
    async delBanner(id) { const all = loadB(), k = all.filter((x) => String(x.id) !== String(id)); saveB(k); return k.length !== all.length; },
  };
}

const clean = (s, n = 200) => String(s ?? "").trim().slice(0, n);
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => { console.error(e); res.status(500).json({ error: "Server error" }); });

// Telegram notification (optional): set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID
const TG_TOKEN = process.env.TELEGRAM_BOT_TOKEN, TG_CHAT = process.env.TELEGRAM_CHAT_ID;
async function notify(o) {
  if (!TG_TOKEN || !TG_CHAT) return;
  const text = `🆕 New order ${o.id}\n${o.game} · ${o.coins} chips · ৳${o.price}\nGame ID: ${o.uid}\nContact: ${o.contact || "-"}\n${o.method} TX: ${o.tx}`;
  try {
    const r = await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TG_CHAT, text }),
    });
    if (!r.ok) console.error("Telegram error", r.status);
  } catch (e) { console.error("Telegram failed", e.message); }
}

// simple per-IP rate limit for public routes (30 requests / minute)
const hits = new Map();
setInterval(() => hits.clear(), 60000).unref();
const limit = (req, res, next) => {
  const n = (hits.get(req.ip) || 0) + 1; hits.set(req.ip, n);
  n > 30 ? res.status(429).json({ error: "Too many requests" }) : next();
};

// Public: place an order (price is calculated here, never trusted from the browser)
app.post("/api/orders", limit, wrap(async (req, res) => {
  const b = req.body || {};
  const game = GAMES[clean(b.game, 50)];
  const millions = parseFloat(clean(b.coins, 20));
  if (!game || !Number.isInteger(millions) || millions < game.min || millions > 100000) return res.status(400).json({ error: "Invalid game or amount (whole crore only)" });
  const uid = clean(b.uid), contact = clean(b.contact), method = clean(b.method, 30), tx = clean(b.tx, 100);
  if (!uid || !method || !tx) return res.status(400).json({ error: "Missing fields" });

  const off = (await store.offers()).find((o) => o.game === clean(b.game, 50) && Number(o.discountPct) > 0);
  let price = Math.ceil(millions * game.rate * (1 - (off ? Number(off.discountPct) : 0) / 100));
  const ref = REFS[clean(b.ref, 40).toUpperCase()];
  if (ref) price = Math.ceil(price * (1 - ref.discountPct / 100));

  const id = "CK" + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase();
  try {
    const order = await store.insert({ id, game: clean(b.game, 50), coins: millions + "Cr", price, uid, contact, method, tx });
    notify(order); // does not block or fail the order
    res.status(201).json(order);
  } catch (e) {
    if (e.dup) return res.status(409).json({ error: "Transaction ID already used" });
    throw e;
  }
}));

// Public: check order status (needs the order ID)
app.get("/api/orders/:id", limit, wrap(async (req, res) => {
  const o = await store.get(req.params.id);
  if (!o) return res.status(404).json({ error: "Not found" });
  res.json({ id: o.id, game: o.game, coins: o.coins, price: o.price, status: o.status });
}));

app.get("/api/games", (req, res) => res.json(GAMES));

app.post("/api/reference", limit, (req, res) => {
  const r = REFS[clean(req.body?.code, 40).toUpperCase()];
  r ? res.json(r) : res.status(404).json({ error: "Invalid code" });
});

// Admin
const admin = (req, res, next) => req.get("x-admin-key") === ADMIN_KEY ? next() : res.status(401).json({ error: "Unauthorized" });
app.get("/api/admin/orders", admin, wrap(async (req, res) => res.json(await store.list())));
app.patch("/api/admin/orders/:id", admin, wrap(async (req, res) => {
  if (!STATUSES.includes(req.body?.status)) return res.status(400).json({ error: "Bad status" });
  const o = await store.setStatus(req.params.id, req.body.status);
  o ? res.json(o) : res.status(404).json({ error: "Not found" });
}));

app.get("/api/offers", wrap(async (req, res) => res.json(await store.offers())));
app.post("/api/admin/offers", admin, wrap(async (req, res) => {
  const b = req.body || {};
  const title = clean(b.title, 80), game = clean(b.game, 50), image = clean(b.image, 500);
  const pct = Math.min(90, Math.max(0, parseInt(b.discountPct, 10) || 0));
  if (!title) return res.status(400).json({ error: "Title required" });
  if (image && !/^https:\/\/[^\s"'()<>]+$/.test(image)) return res.status(400).json({ error: "Image must be an https:// link" });
  if ((await store.offers()).length >= 6) return res.status(400).json({ error: "Maximum 6 offers. Delete one first." });
  if (game && !GAMES[game]) return res.status(400).json({ error: "Unknown game" });
  res.status(201).json(await store.addOffer({ title, text: clean(b.text, 300), game, discountPct: pct, image }));
}));
app.delete("/api/admin/offers/:id", admin, wrap(async (req, res) =>
  (await store.delOffer(req.params.id)) ? res.json({ ok: true }) : res.status(404).json({ error: "Not found" })));

app.get("/api/banners", wrap(async (req, res) => res.json(await store.banners())));
app.post("/api/admin/banners", admin, wrap(async (req, res) => {
  const b = req.body || {};
  const img = clean(b.img, 500), game = clean(b.game, 50);
  if (!/^https:\/\//i.test(img)) return res.status(400).json({ error: "Image link must start with https://" });
  if (game && !GAMES[game]) return res.status(400).json({ error: "Unknown game" });
  if ((await store.banners()).length >= 6) return res.status(400).json({ error: "Maximum 6 banners" });
  res.status(201).json(await store.addBanner({ img, game }));
}));
app.delete("/api/admin/banners/:id", admin, wrap(async (req, res) =>
  (await store.delBanner(req.params.id)) ? res.json({ ok: true }) : res.status(404).json({ error: "Not found" })));

app.use("/admin", express.static(path.join(__dirname, "public")));
app.get("/", (req, res) => res.send("Chips kinun API is running"));

store.init()
  .then(() => app.listen(process.env.PORT || 3000, () => console.log("Chips kinun API running")))
  .catch((e) => { console.error("Database init failed:", e.message); process.exit(1); });
